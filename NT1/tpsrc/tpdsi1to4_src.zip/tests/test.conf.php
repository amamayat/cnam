<?php
if (! defined('SIMPLE_TEST')) {
  define('SIMPLE_TEST', 'simpletest/');
}

require_once(SIMPLE_TEST . 'autorun.php');
require_once(SIMPLE_TEST . 'web_tester.php');

$reporter = 'HtmlReporter';

?>
