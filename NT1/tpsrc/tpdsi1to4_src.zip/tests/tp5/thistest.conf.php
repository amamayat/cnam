<?php
if ( ! defined('TP_NAME') ) define('TP_NAME', 'tp5');
$GLOBALS['targetDir'] = $targetDir = '../../' . TP_NAME;
?>
