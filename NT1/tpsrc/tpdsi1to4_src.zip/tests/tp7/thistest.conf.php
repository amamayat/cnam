<?php
if ( ! defined('TP_NAME') ) define('TP_NAME', 'tp7');
$GLOBALS['targetDir'] = $targetDir = '../../' . TP_NAME;
?>
