<?php                                                                         
class AbstractLoginController {
  function isValidLogin($login)
  {
    return false;
  }
  
  function isValidPassword($login, $password)
  {
    return false;
  }
}
?>
